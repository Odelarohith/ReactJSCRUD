import logo from './logo.svg';
import './App.css';
import "bootstrap/dist/css/bootstrap.css";

import Home from './component/pages/home';
import About from './component/pages/about';
import Contact from './component/pages/contact';
import Navbar from './component/layout/navbar';
import Addusers from './component/users/addusers';
import Edit from './component/users/edit';
import Pagenotfound from './component/pages/pagenotfound';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";


function App() {
  return (
    <Router>
    <div className="App">
      <Navbar/>
      <Switch>
        <Route exact path="/" component={Home}></Route>
        <Route exact path="/about" component={About}></Route>
        <Route exact path="/contact" component={Contact}></Route>
        <Route exact path="/users/addusers" component={Addusers}></Route>
        <Route exact path="/users/edit/:id" component={Edit}></Route>
        <Route exact path="*" component={Pagenotfound}></Route>
      </Switch> 
    </div>
    </Router>
  );
}

export default App;
