import React from 'react'

export default function About() {
  return (
    <div>
      <h1>About page</h1>
    </div>
  )
}
