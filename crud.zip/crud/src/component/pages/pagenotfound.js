import React from 'react'

export default function Pagenotfound() {
  return (
    <div>
      <h1>Pagenotfound</h1>
    </div>
  )
}
