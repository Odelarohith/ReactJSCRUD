import React from 'react'

export default function Contact() {
  return (
    <div>
     <h1>Contact pages</h1>
    </div>
  )
}
