import {React, useState, useEffect} from 'react';
import { useHistory, useParams } from "react-router-dom";
import axios from "axios";

export default function Edit() {

    let history = useHistory();
    const {id} = useParams();
    console.log(id);
    const [user, setUsers] = useState({
        name: "",
        username: "",
        email: "",
    });

    const {name,username,email} = user;
    const onInputChange = e => {
        setUsers({...user,[e.target.name]: e.target.value})
    };

    useEffect(() => {
        loadUser();
    }, []);

    const onSubmit = async e => {
        e.preventDefault();
        await axios.put(`http://localhost:3001/users/${id}`, user);
        history.push("/");
    }

    const loadUser = async () => {
        const result = await axios.get(`http://localhost:3001/users/${id}`);
        setUsers(result.data);
    };

  return (
    <div className="container">
      <form onSubmit={e => onSubmit(e)}>
        <div className="form-group">
          <label htmlFor="Name">Name</label>
          <input type="name" 
          className="form-control"  
          placeholder="Name" 
          name="name"
          value={name}
          onChange={e=> onInputChange(e)}
           />
        </div>
        <div className="form-group">
          <label htmlFor="UserName">User name</label>
          <input type="text"
           className="form-control"  
           placeholder="User Name" 
           name="username"
           value={username}
           onChange={e=> onInputChange(e)}
           />
        </div>
        <div className="form-group">
          <label htmlFor="Email">Email</label>
          <input type="text" 
          className="form-control"  
          placeholder="Email" 
          name="email"
          value={email}
          onChange={e=> onInputChange(e)}
          />
        </div>
        
        <button type="submit" className="btn btn-primary btn-block">Update User</button>
      </form>
    </div>
  )
}
